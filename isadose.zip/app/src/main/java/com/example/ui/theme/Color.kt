package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Minimalism Color Palette
val MinimalBluePrimary = Color(0xFF0061A4)
val MinimalBluePrimaryVariant = Color(0xFF001D36)
val MinimalBlueContainer = Color(0xFFD1E4FF)
val MinimalOnBlueContainer = Color(0xFF001D36)

val MinimalPurpleAccent = Color(0xFF6750A4)
val MinimalPurpleContainer = Color(0xFFE8DEF8)
val MinimalOnPurpleContainer = Color(0xFF1D192B)

val MinimalLightBackground = Color(0xFFFDFBFF)
val MinimalLightSurface = Color(0xFFFFFFFF)
val MinimalLightSurfaceVariant = Color(0xFFF2F0F4)
val MinimalLightBorder = Color(0xFFC4C6D0)
val MinimalLightOutlineVariant = Color(0xFFE1E2EC)

val MinimalDarkBackground = Color(0xFF111318)
val MinimalDarkSurface = Color(0xFF191C20)
val MinimalDarkSurfaceVariant = Color(0xFF262A30)
val MinimalDarkBorder = Color(0xFF44474E)

// Text Colors
val TextPrimaryLight = Color(0xFF1B1B1F)
val TextSecondaryLight = Color(0xFF44474E)
val TextNavyLight = Color(0xFF001D36)

val TextPrimaryDark = Color(0xFFE2E2E9)
val TextSecondaryDark = Color(0xFFC4C6D0)

// Status Colors for Clean Minimalism
val StatusTakenGreen = Color(0xFF1B6C31)
val StatusTakenBg = Color(0xFFD4F5DA)
val StatusTakenDarkBg = Color(0xFF0F3819)

val StatusMissedRed = Color(0xFFBA1A1A)
val StatusMissedBg = Color(0xFFFFDAD6)
val StatusMissedDarkBg = Color(0xFF410002)

val StatusSkippedOrange = Color(0xFF9E4A00)
val StatusSkippedBg = Color(0xFFFFDCC2)
val StatusSkippedDarkBg = Color(0xFF3B1800)

val StatusUpcomingBlue = Color(0xFF0061A4)
val StatusUpcomingBg = Color(0xFFD1E4FF)
val StatusUpcomingDarkBg = Color(0xFF003258)
