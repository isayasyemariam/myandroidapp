package com.example.ui.navigation

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import com.example.i18n.StringResources
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.auth.ForgotPasswordScreen
import com.example.ui.screens.auth.LoginScreen
import com.example.ui.screens.auth.SignUpScreen
import com.example.ui.screens.dashboard.DashboardScreen
import com.example.ui.screens.dose.DoseHistoryScreen
import com.example.ui.screens.dose.TodayScheduleScreen
import com.example.ui.screens.medication.AddEditMedicationScreen
import com.example.ui.screens.medication.MedicationDetailScreen
import com.example.ui.screens.medication.MedicationsScreen
import com.example.ui.screens.settings.AboutScreen
import com.example.ui.screens.settings.AccountDeletionScreen
import com.example.ui.screens.settings.AppSettingsScreen
import com.example.ui.screens.settings.LanguageSettingsScreen
import com.example.ui.screens.settings.MedicalDisclaimerScreen
import com.example.ui.screens.settings.NotificationSettingsScreen
import com.example.ui.screens.settings.PrivacyPolicyScreen
import com.example.ui.screens.settings.ProfileScreen
import com.example.ui.screens.settings.TermsOfUseScreen
import com.example.ui.screens.settings.ThemeSettingsScreen
import com.example.ui.screens.stats.StatisticsScreen
import com.example.viewmodel.IsaDoseViewModel

@Composable
fun IsaDoseNavHost(
    navController: NavHostController,
    viewModel: IsaDoseViewModel
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val userSettings by viewModel.userSettings.collectAsState()
    val language by viewModel.currentLanguage.collectAsState()
    val medications by viewModel.medications.collectAsState()
    val todayDoses by viewModel.todayDoses.collectAsState()
    val historyDoses by viewModel.historyDoses.collectAsState()
    val stats by viewModel.stats.collectAsState()
    val selectedMedication by viewModel.selectedMedication.collectAsState()
    val selectedHistoryDate by viewModel.selectedHistoryDate.collectAsState()

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val bottomNavRoutes = listOf(
        Screen.Dashboard.route,
        Screen.Medications.route,
        Screen.TodaySchedule.route,
        Screen.Statistics.route,
        Screen.Profile.route
    )

    val showBottomNav = currentUser != null && currentRoute in bottomNavRoutes

    Scaffold(
        bottomBar = {
            if (showBottomNav) {
                val navItemColors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    selectedTextColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                )

                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(72.dp)
                ) {
                    NavigationBarItem(
                        selected = currentRoute == Screen.Dashboard.route,
                        onClick = {
                            if (currentRoute != Screen.Dashboard.route) {
                                navController.navigate(Screen.Dashboard.route) {
                                    popUpTo(Screen.Dashboard.route) { inclusive = true }
                                }
                            }
                        },
                        icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
                        label = { Text(StringResources.get("dashboard", language)) },
                        colors = navItemColors,
                        modifier = Modifier.testTag("nav_bottom_dashboard")
                    )
                    NavigationBarItem(
                        selected = currentRoute == Screen.Medications.route,
                        onClick = {
                            if (currentRoute != Screen.Medications.route) {
                                navController.navigate(Screen.Medications.route) {
                                    popUpTo(Screen.Dashboard.route)
                                }
                            }
                        },
                        icon = { Icon(Icons.Default.Medication, contentDescription = "Medications") },
                        label = { Text(StringResources.get("medications", language)) },
                        colors = navItemColors,
                        modifier = Modifier.testTag("nav_bottom_medications")
                    )
                    NavigationBarItem(
                        selected = currentRoute == Screen.TodaySchedule.route,
                        onClick = {
                            if (currentRoute != Screen.TodaySchedule.route) {
                                navController.navigate(Screen.TodaySchedule.route) {
                                    popUpTo(Screen.Dashboard.route)
                                }
                            }
                        },
                        icon = { Icon(Icons.Default.CalendarToday, contentDescription = "Schedule") },
                        label = { Text(StringResources.get("schedule", language)) },
                        colors = navItemColors,
                        modifier = Modifier.testTag("nav_bottom_schedule")
                    )
                    NavigationBarItem(
                        selected = currentRoute == Screen.Statistics.route,
                        onClick = {
                            if (currentRoute != Screen.Statistics.route) {
                                navController.navigate(Screen.Statistics.route) {
                                    popUpTo(Screen.Dashboard.route)
                                }
                            }
                        },
                        icon = { Icon(Icons.Default.Timeline, contentDescription = "Statistics") },
                        label = { Text(StringResources.get("statistics", language)) },
                        colors = navItemColors,
                        modifier = Modifier.testTag("nav_bottom_stats")
                    )
                    NavigationBarItem(
                        selected = currentRoute == Screen.Profile.route,
                        onClick = {
                            if (currentRoute != Screen.Profile.route) {
                                navController.navigate(Screen.Profile.route) {
                                    popUpTo(Screen.Dashboard.route)
                                }
                            }
                        },
                        icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
                        label = { Text(StringResources.get("profile", language)) },
                        colors = navItemColors,
                        modifier = Modifier.testTag("nav_bottom_profile")
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Splash.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Splash.route) {
                SplashScreen(
                    isLoggedIn = currentUser != null,
                    language = language,
                    onNavigateNext = { isLoggedIn ->
                        if (isLoggedIn) {
                            navController.navigate(Screen.Dashboard.route) {
                                popUpTo(Screen.Splash.route) { inclusive = true }
                            }
                        } else {
                            navController.navigate(Screen.Onboarding.route) {
                                popUpTo(Screen.Splash.route) { inclusive = true }
                            }
                        }
                    }
                )
            }

            composable(Screen.Onboarding.route) {
                OnboardingScreen(
                    language = language,
                    onNavigateToSignUp = { navController.navigate(Screen.SignUp.route) },
                    onNavigateToLogin = { navController.navigate(Screen.Login.route) }
                )
            }

            composable(Screen.Login.route) {
                LoginScreen(
                    language = language,
                    onLogin = { email, pass, onResult -> viewModel.login(email, pass, onResult) },
                    onNavigateToSignUp = { navController.navigate(Screen.SignUp.route) },
                    onNavigateToForgotPassword = { navController.navigate(Screen.ForgotPassword.route) },
                    onLoginSuccess = {
                        navController.navigate(Screen.Dashboard.route) {
                            popUpTo(Screen.Login.route) { inclusive = true }
                            popUpTo(Screen.Onboarding.route) { inclusive = true }
                        }
                    }
                )
            }

            composable(Screen.SignUp.route) {
                SignUpScreen(
                    language = language,
                    onSignUp = { email, pass, name, onResult -> viewModel.signUp(email, pass, name, onResult) },
                    onNavigateToLogin = { navController.navigate(Screen.Login.route) },
                    onSignUpSuccess = {
                        navController.navigate(Screen.Dashboard.route) {
                            popUpTo(Screen.SignUp.route) { inclusive = true }
                            popUpTo(Screen.Onboarding.route) { inclusive = true }
                        }
                    }
                )
            }

            composable(Screen.ForgotPassword.route) {
                ForgotPasswordScreen(
                    language = language,
                    onResetPassword = { email, newPass, onResult -> viewModel.resetPassword(email, newPass, onResult) },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.Dashboard.route) {
                DashboardScreen(
                    user = currentUser,
                    todayDoses = todayDoses,
                    stats = stats,
                    language = language,
                    onTakeDose = { viewModel.takeDose(it) },
                    onSkipDose = { viewModel.skipDose(it) },
                    onMissDose = { viewModel.missDose(it) },
                    onAddMedication = {
                        viewModel.selectMedication(null)
                        navController.navigate(Screen.AddEditMedication.route)
                    },
                    onViewSchedule = { navController.navigate(Screen.TodaySchedule.route) }
                )
            }

            composable(Screen.Medications.route) {
                MedicationsScreen(
                    medications = medications,
                    language = language,
                    onMedicationClick = { med ->
                        viewModel.selectMedication(med)
                        navController.navigate(Screen.MedicationDetail.route)
                    },
                    onAddMedicationClick = {
                        viewModel.selectMedication(null)
                        navController.navigate(Screen.AddEditMedication.route)
                    }
                )
            }

            composable(Screen.AddEditMedication.route) {
                AddEditMedicationScreen(
                    language = language,
                    existingMedication = selectedMedication,
                    onSave = { name, doseAmount, doseUnit, instructions, frequency, scheduledTimes, daysOfWeek, startDate, endDate, notes, medId ->
                        viewModel.saveMedication(
                            name = name,
                            doseAmount = doseAmount,
                            doseUnit = doseUnit,
                            instructions = instructions,
                            frequency = frequency,
                            scheduledTimes = scheduledTimes,
                            daysOfWeek = daysOfWeek,
                            startDate = startDate,
                            endDate = endDate,
                            notes = notes,
                            existingMedId = medId,
                            onSuccess = { navController.popBackStack() },
                            onError = { /* Shown on screen */ }
                        )
                    },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.MedicationDetail.route) {
                MedicationDetailScreen(
                    medication = selectedMedication,
                    language = language,
                    onEdit = { med ->
                        viewModel.selectMedication(med)
                        navController.navigate(Screen.AddEditMedication.route)
                    },
                    onToggleActive = { med, isActive -> viewModel.toggleMedicationActive(med.id, isActive) },
                    onDelete = { med -> viewModel.deleteMedication(med.id) },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.TodaySchedule.route) {
                TodayScheduleScreen(
                    todayDoses = todayDoses,
                    language = language,
                    onTakeDose = { viewModel.takeDose(it) },
                    onSkipDose = { viewModel.skipDose(it) },
                    onMissDose = { viewModel.missDose(it) },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.DoseHistory.route) {
                DoseHistoryScreen(
                    doses = historyDoses,
                    selectedDate = selectedHistoryDate,
                    language = language,
                    onSelectDate = { viewModel.setHistoryDate(it) },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.Statistics.route) {
                StatisticsScreen(
                    stats = stats,
                    language = language
                )
            }

            composable(Screen.Profile.route) {
                ProfileScreen(
                    user = currentUser,
                    language = language,
                    onNavigateToSettings = { navController.navigate(Screen.AppSettings.route) },
                    onLogout = {
                        viewModel.logout()
                        navController.navigate(Screen.Login.route) {
                            popUpTo(Screen.Dashboard.route) { inclusive = true }
                        }
                    }
                )
            }

            composable(Screen.AppSettings.route) {
                AppSettingsScreen(
                    language = language,
                    onNavigateToNotifications = { navController.navigate(Screen.NotificationSettings.route) },
                    onNavigateToLanguage = { navController.navigate(Screen.LanguageSettings.route) },
                    onNavigateToTheme = { navController.navigate(Screen.ThemeSettings.route) },
                    onNavigateToPrivacy = { navController.navigate(Screen.PrivacyPolicy.route) },
                    onNavigateToTerms = { navController.navigate(Screen.TermsOfUse.route) },
                    onNavigateToDisclaimer = { navController.navigate(Screen.MedicalDisclaimer.route) },
                    onNavigateToAccountDeletion = { navController.navigate(Screen.AccountDeletion.route) },
                    onNavigateToAbout = { navController.navigate(Screen.About.route) },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.NotificationSettings.route) {
                NotificationSettingsScreen(
                    userSettings = userSettings,
                    language = language,
                    onSavePreferences = { sound, vibrate, lead ->
                        viewModel.updateNotifications(sound, vibrate, lead)
                    },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.LanguageSettings.route) {
                LanguageSettingsScreen(
                    currentLanguage = language,
                    onSelectLanguage = { lang -> viewModel.setLanguage(lang.code) },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.ThemeSettings.route) {
                ThemeSettingsScreen(
                    currentTheme = userSettings.themeMode,
                    language = language,
                    onSelectTheme = { mode -> viewModel.setTheme(mode) },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.PrivacyPolicy.route) {
                PrivacyPolicyScreen(
                    language = language,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.TermsOfUse.route) {
                TermsOfUseScreen(
                    language = language,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.MedicalDisclaimer.route) {
                MedicalDisclaimerScreen(
                    language = language,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.AccountDeletion.route) {
                AccountDeletionScreen(
                    language = language,
                    onConfirmDelete = { onResult ->
                        viewModel.deleteAccount { success, err ->
                            onResult(success, err)
                            if (success) {
                                navController.navigate(Screen.Onboarding.route) {
                                    popUpTo(Screen.Dashboard.route) { inclusive = true }
                                }
                            }
                        }
                    },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.About.route) {
                AboutScreen(
                    language = language,
                    onNavigateBack = { navController.popBackStack() }
                )
            }
        }
    }
}
