package com.example.ui.screens.dose

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DoseEvent
import com.example.data.model.DoseStatus
import com.example.i18n.AppLanguage
import com.example.i18n.StringResources
import com.example.ui.components.DoseCard
import com.example.ui.components.DoseStatusBadge
import com.example.ui.components.IsaDoseTopAppBar
import com.example.util.DateUtils

@Composable
fun TodayScheduleScreen(
    todayDoses: List<DoseEvent>,
    language: AppLanguage,
    onTakeDose: (String) -> Unit,
    onSkipDose: (String) -> Unit,
    onMissDose: (String) -> Unit,
    onNavigateBack: () -> Unit
) {
    var selectedFilter by remember { mutableStateOf("ALL") }

    val filteredList = when (selectedFilter) {
        "UPCOMING" -> todayDoses.filter { it.status == DoseStatus.UPCOMING.name }
        "TAKEN" -> todayDoses.filter { it.status == DoseStatus.TAKEN.name }
        "MISSED" -> todayDoses.filter { it.status == DoseStatus.MISSED.name }
        "SKIPPED" -> todayDoses.filter { it.status == DoseStatus.SKIPPED.name }
        else -> todayDoses
    }

    Scaffold(
        topBar = {
            IsaDoseTopAppBar(
                title = StringResources.get("today_schedule", language),
                onBack = onNavigateBack
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
        ) {
            // Filter Pills
            val filterOptions = listOf(
                Pair("ALL", StringResources.get("all", language)),
                Pair("UPCOMING", StringResources.get("upcoming", language)),
                Pair("TAKEN", StringResources.get("taken_doses", language)),
                Pair("MISSED", StringResources.get("missed_doses", language)),
                Pair("SKIPPED", StringResources.get("skipped_doses", language))
            )

            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filterOptions) { (key, label) ->
                    val isSelected = selectedFilter == key
                    Button(
                        onClick = { selectedFilter = key },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    ) {
                        Text(text = label, style = MaterialTheme.typography.labelLarge)
                    }
                }
            }

            if (filteredList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No doses found in this category.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredList, key = { it.id }) { dose ->
                        DoseCard(
                            dose = dose,
                            language = language,
                            onTake = { onTakeDose(dose.id) },
                            onSkip = { onSkipDose(dose.id) },
                            onMiss = { onMissDose(dose.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DoseHistoryScreen(
    doses: List<DoseEvent>,
    selectedDate: String?,
    language: AppLanguage,
    onSelectDate: (String?) -> Unit,
    onNavigateBack: () -> Unit
) {
    val pastDates = remember { listOf<String?>(null) + DateUtils.getDatesForPastDays(14).reversed() }

    Scaffold(
        topBar = {
            IsaDoseTopAppBar(
                title = StringResources.get("dose_history", language),
                onBack = onNavigateBack
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
        ) {
            // Date Filter Row
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(pastDates) { dateStr ->
                    val isSelected = selectedDate == dateStr
                    val label = if (dateStr == null) {
                        StringResources.get("all", language)
                    } else if (dateStr == DateUtils.getTodayDateString()) {
                        "Today"
                    } else {
                        dateStr.substring(5) // MM-dd
                    }

                    Button(
                        onClick = { onSelectDate(dateStr) },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    ) {
                        Text(text = label, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }

            if (doses.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = StringResources.get("no_history_records", language),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(doses, key = { it.id }) { dose ->
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = dose.medicationName,
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = "${dose.doseAmount} ${dose.doseUnit}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = "${dose.scheduledDate} ${dose.scheduledTime}",
                                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        DoseStatusBadge(status = dose.status, language = language)
                                    }
                                }

                                if (dose.actionTimestamp != null) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "Recorded at: ${DateUtils.formatActionTime(dose.actionTimestamp)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
