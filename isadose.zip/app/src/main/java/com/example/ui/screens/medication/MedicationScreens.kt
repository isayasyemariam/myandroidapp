package com.example.ui.screens.medication

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Medication
import com.example.i18n.AppLanguage
import com.example.i18n.StringResources
import com.example.ui.components.IsaDoseTopAppBar
import com.example.ui.theme.StatusMissedRed
import com.example.ui.theme.StatusTakenGreen
import com.example.util.DateUtils

@Composable
fun MedicationsScreen(
    medications: List<Medication>,
    language: AppLanguage,
    onMedicationClick: (Medication) -> Unit,
    onAddMedicationClick: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Active, 1 = Inactive
    val filteredMeds = if (selectedTab == 0) {
        medications.filter { it.isActive }
    } else {
        medications.filter { !it.isActive }
    }

    Scaffold(
        topBar = {
            IsaDoseTopAppBar(title = StringResources.get("medications", language))
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddMedicationClick,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier.testTag("medications_add_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = StringResources.get("add_medication", language))
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
        ) {
            // Tabs: Active vs Inactive
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { selectedTab = 0 },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedTab == 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (selectedTab == 0) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(text = "${StringResources.get("active_medications", language)} (${medications.count { it.isActive }})")
                }
                Button(
                    onClick = { selectedTab = 1 },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedTab == 1) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (selectedTab == 1) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(text = "${StringResources.get("inactive_medications", language)} (${medications.count { !it.isActive }})")
                }
            }

            if (filteredMeds.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Medication,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = if (selectedTab == 0) "No active medications found" else "No paused medications",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredMeds, key = { it.id }) { med ->
                        MedicationCard(
                            medication = med,
                            language = language,
                            onClick = { onMedicationClick(med) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MedicationCard(
    medication: Medication,
    language: AppLanguage,
    onClick: () -> Unit
) {
    val times = DateUtils.parseScheduledTimesJson(medication.scheduledTimesJson)

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("medication_card_${medication.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(
                        color = if (medication.isActive) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Medication,
                    contentDescription = null,
                    tint = if (medication.isActive) MaterialTheme.colorScheme.primary else Color.Gray,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = medication.name,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "${medication.doseAmount} ${medication.doseUnit} • ${medication.instructions}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Schedule,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = times.joinToString(", "),
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditMedicationScreen(
    language: AppLanguage,
    existingMedication: Medication? = null,
    onSave: (
        name: String,
        doseAmount: String,
        doseUnit: String,
        instructions: String,
        frequency: String,
        scheduledTimes: List<String>,
        daysOfWeek: List<Int>,
        startDate: String,
        endDate: String?,
        notes: String?,
        medId: String?
    ) -> Unit,
    onNavigateBack: () -> Unit
) {
    var name by remember { mutableStateOf(existingMedication?.name ?: "") }
    var doseAmount by remember { mutableStateOf(existingMedication?.doseAmount ?: "1") }
    var doseUnit by remember { mutableStateOf(existingMedication?.doseUnit ?: "tablets") }
    var instructions by remember { mutableStateOf(existingMedication?.instructions ?: "With food") }
    var frequency by remember { mutableStateOf(existingMedication?.frequency ?: "Once daily") }
    var startDate by remember { mutableStateOf(existingMedication?.startDate ?: DateUtils.getTodayDateString()) }
    var endDate by remember { mutableStateOf(existingMedication?.endDate ?: "") }
    var notes by remember { mutableStateOf(existingMedication?.notes ?: "") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val scheduledTimes = remember {
        mutableStateListOf<String>().apply {
            if (existingMedication != null) {
                addAll(DateUtils.parseScheduledTimesJson(existingMedication.scheduledTimesJson))
            } else {
                add("08:00")
            }
        }
    }

    val doseUnits = listOf("tablets", "capsules", "pills", "mg", "ml", "drops", "puffs", "units")
    val instructionOptions = listOf("With food", "Before meal", "After meal", "On empty stomach", "At bedtime", "As needed")
    val frequencyOptions = listOf("Once daily", "Twice daily", "3 times daily", "4 times daily", "Every 8 hours")

    Scaffold(
        topBar = {
            IsaDoseTopAppBar(
                title = if (existingMedication == null) StringResources.get("add_medication", language) else StringResources.get("edit_medication", language),
                onBack = onNavigateBack
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(innerPadding)
                .padding(20.dp)
        ) {
            if (errorMessage != null) {
                Text(
                    text = errorMessage!!,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
            }

            // Name
            OutlinedTextField(
                value = name,
                onValueChange = { name = it; errorMessage = null },
                label = { Text(StringResources.get("med_name", language)) },
                placeholder = { Text(StringResources.get("med_name_hint", language)) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("med_input_name")
            )
            Spacer(modifier = Modifier.height(14.dp))

            // Dose Amount & Unit Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = doseAmount,
                    onValueChange = { doseAmount = it; errorMessage = null },
                    label = { Text(StringResources.get("dose_amount", language)) },
                    placeholder = { Text("e.g. 500") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("med_input_amount")
                )
            }
            Spacer(modifier = Modifier.height(12.dp))

            // Dose Unit Selector
            Text(
                text = StringResources.get("dose_unit", language),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            ScrollableTabRow(
                selectedTabIndex = doseUnits.indexOf(doseUnit).coerceAtLeast(0),
                edgePadding = 0.dp,
                divider = {}
            ) {
                doseUnits.forEach { unit ->
                    Tab(
                        selected = doseUnit == unit,
                        onClick = { doseUnit = unit },
                        text = { Text(unit) }
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))

            // Instructions Selector
            Text(
                text = StringResources.get("instructions", language),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            ScrollableTabRow(
                selectedTabIndex = instructionOptions.indexOf(instructions).coerceAtLeast(0),
                edgePadding = 0.dp,
                divider = {}
            ) {
                instructionOptions.forEach { opt ->
                    Tab(
                        selected = instructions == opt,
                        onClick = { instructions = opt },
                        text = { Text(opt) }
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))

            // Frequency
            Text(
                text = StringResources.get("frequency", language),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            ScrollableTabRow(
                selectedTabIndex = frequencyOptions.indexOf(frequency).coerceAtLeast(0),
                edgePadding = 0.dp,
                divider = {}
            ) {
                frequencyOptions.forEach { opt ->
                    Tab(
                        selected = frequency == opt,
                        onClick = {
                            frequency = opt
                            // Auto-adjust default times
                            when (opt) {
                                "Once daily" -> {
                                    scheduledTimes.clear()
                                    scheduledTimes.add("08:00")
                                }
                                "Twice daily" -> {
                                    scheduledTimes.clear()
                                    scheduledTimes.addAll(listOf("08:00", "20:00"))
                                }
                                "3 times daily" -> {
                                    scheduledTimes.clear()
                                    scheduledTimes.addAll(listOf("08:00", "14:00", "20:00"))
                                }
                                "4 times daily" -> {
                                    scheduledTimes.clear()
                                    scheduledTimes.addAll(listOf("08:00", "12:00", "16:00", "20:00"))
                                }
                                "Every 8 hours" -> {
                                    scheduledTimes.clear()
                                    scheduledTimes.addAll(listOf("06:00", "14:00", "22:00"))
                                }
                            }
                        },
                        text = { Text(opt) }
                    )
                }
            }
            Spacer(modifier = Modifier.height(18.dp))

            // Scheduled Times
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = StringResources.get("scheduled_times", language),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                TextButton(
                    onClick = {
                        val nextHour = (8 + (scheduledTimes.size * 4)) % 24
                        scheduledTimes.add(String.format("%02d:00", nextHour))
                    },
                    modifier = Modifier.testTag("med_add_time_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(StringResources.get("add_time", language))
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                scheduledTimes.forEachIndexed { index, timeStr ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = timeStr,
                            onValueChange = { scheduledTimes[index] = it },
                            label = { Text("Reminder #${index + 1} (HH:mm)") },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        )
                        if (scheduledTimes.size > 1) {
                            IconButton(onClick = { scheduledTimes.removeAt(index) }) {
                                Icon(Icons.Default.Close, contentDescription = "Remove time", tint = StatusMissedRed)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Start Date & End Date
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = startDate,
                    onValueChange = { startDate = it },
                    label = { Text(StringResources.get("start_date", language)) },
                    placeholder = { Text("YYYY-MM-DD") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = endDate,
                    onValueChange = { endDate = it },
                    label = { Text(StringResources.get("end_date", language)) },
                    placeholder = { Text("YYYY-MM-DD (Optional)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Notes
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text(StringResources.get("notes", language)) },
                placeholder = { Text(StringResources.get("notes_hint", language)) },
                minLines = 3,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("med_input_notes")
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Save Button
            Button(
                onClick = {
                    if (name.isBlank()) {
                        errorMessage = "Please enter medication name."
                        return@Button
                    }
                    if (doseAmount.isBlank()) {
                        errorMessage = "Please enter dose amount."
                        return@Button
                    }
                    if (scheduledTimes.isEmpty()) {
                        errorMessage = "Please specify at least one reminder time."
                        return@Button
                    }
                    onSave(
                        name,
                        doseAmount,
                        doseUnit,
                        instructions,
                        frequency,
                        scheduledTimes.toList(),
                        emptyList(),
                        startDate,
                        endDate.takeIf { it.isNotBlank() },
                        notes.takeIf { it.isNotBlank() },
                        existingMedication?.id
                    )
                },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("med_save_button")
            ) {
                Text(
                    text = StringResources.get("save_medication", language),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }
        }
    }
}

@Composable
fun MedicationDetailScreen(
    medication: Medication?,
    language: AppLanguage,
    onEdit: (Medication) -> Unit,
    onToggleActive: (Medication, Boolean) -> Unit,
    onDelete: (Medication) -> Unit,
    onNavigateBack: () -> Unit
) {
    if (medication == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No medication selected.")
        }
        return
    }

    var showDeleteDialog by remember { mutableStateOf(false) }
    val times = DateUtils.parseScheduledTimesJson(medication.scheduledTimesJson)

    Scaffold(
        topBar = {
            IsaDoseTopAppBar(
                title = StringResources.get("medication_details", language),
                onBack = onNavigateBack,
                actions = {
                    IconButton(onClick = { onEdit(medication) }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit")
                    }
                    IconButton(onClick = { showDeleteDialog = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = StatusMissedRed)
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(innerPadding)
                .padding(20.dp)
        ) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = medication.name,
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Surface(
                            color = if (medication.isActive) StatusTakenGreen.copy(alpha = 0.15f) else Color.Gray.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = if (medication.isActive) "Active" else "Paused",
                                color = if (medication.isActive) StatusTakenGreen else Color.Gray,
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Dosage: ${medication.doseAmount} ${medication.doseUnit}",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Instructions: ${medication.instructions}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Frequency: ${medication.frequency}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Schedule Times Card
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = StringResources.get("scheduled_times", language),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        times.forEach { t ->
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = t,
                                    color = MaterialTheme.colorScheme.primary,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Duration & Notes
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Treatment Period",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Started: ${medication.startDate}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = if (medication.endDate != null) "Ends: ${medication.endDate}" else StringResources.get("ongoing_treatment", language),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (!medication.notes.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = StringResources.get("notes", language),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = medication.notes,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Pause / Activate Action Button
            Button(
                onClick = { onToggleActive(medication, !medication.isActive) },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (medication.isActive) Color(0xFFEF6C00) else StatusTakenGreen
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Icon(
                    imageVector = if (medication.isActive) Icons.Default.PauseCircle else Icons.Default.PlayCircle,
                    contentDescription = null
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (medication.isActive) StringResources.get("pause_medication", language) else StringResources.get("activate_medication", language),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text(StringResources.get("delete_medication", language)) },
            text = { Text(StringResources.get("delete_med_confirm", language)) },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteDialog = false
                        onDelete(medication)
                        onNavigateBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusMissedRed)
                ) {
                    Text(StringResources.get("delete", language))
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text(StringResources.get("cancel", language))
                }
            }
        )
    }
}
