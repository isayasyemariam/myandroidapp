package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val CleanMinimalismDarkColorScheme = darkColorScheme(
    primary = Color(0xFF9ECAFF),
    onPrimary = Color(0xFF003258),
    primaryContainer = Color(0xFF00497D),
    onPrimaryContainer = Color(0xFFD1E4FF),
    secondary = Color(0xFFCFBCFF),
    onSecondary = Color(0xFF381E72),
    secondaryContainer = Color(0xFF4F378B),
    onSecondaryContainer = Color(0xFFE8DEF8),
    tertiary = Color(0xFFB5C4FF),
    background = MinimalDarkBackground,
    onBackground = TextPrimaryDark,
    surface = MinimalDarkSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = MinimalDarkSurfaceVariant,
    onSurfaceVariant = TextSecondaryDark,
    outline = MinimalDarkBorder,
    outlineVariant = Color(0xFF35393F),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005)
)

private val CleanMinimalismLightColorScheme = lightColorScheme(
    primary = MinimalBluePrimary,
    onPrimary = Color.White,
    primaryContainer = MinimalBlueContainer,
    onPrimaryContainer = MinimalOnBlueContainer,
    secondary = MinimalPurpleAccent,
    onSecondary = Color.White,
    secondaryContainer = MinimalPurpleContainer,
    onSecondaryContainer = MinimalOnPurpleContainer,
    tertiary = Color(0xFF0061A4),
    background = MinimalLightBackground,
    onBackground = TextPrimaryLight,
    surface = MinimalLightSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = MinimalLightSurfaceVariant,
    onSurfaceVariant = TextSecondaryLight,
    outline = MinimalLightBorder,
    outlineVariant = MinimalLightOutlineVariant,
    error = StatusMissedRed,
    onError = Color.White
)

@Composable
fun IsaDoseTheme(
    themeMode: String = "SYSTEM", // "SYSTEM", "LIGHT", "DARK"
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val darkTheme = when (themeMode) {
        "DARK" -> true
        "LIGHT" -> false
        else -> isSystemInDarkTheme()
    }

    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> CleanMinimalismDarkColorScheme
        else -> CleanMinimalismLightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Backward compatibility alias for tests and template
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    IsaDoseTheme(
        themeMode = if (darkTheme) "DARK" else "LIGHT",
        dynamicColor = dynamicColor,
        content = content
    )
}
