package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.IsaDoseDatabase
import com.example.data.model.DoseEvent
import com.example.data.model.Medication
import com.example.data.model.User
import com.example.data.model.UserSettings
import com.example.data.repository.AdherenceStats
import com.example.data.repository.AuthRepository
import com.example.data.repository.DoseRepository
import com.example.data.repository.MedicationRepository
import com.example.data.repository.SettingsRepository
import com.example.i18n.AppLanguage
import com.example.reminder.NotificationHelper
import com.example.util.DateUtils
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class IsaDoseViewModel(
    application: Application,
    val authRepository: AuthRepository,
    val medicationRepository: MedicationRepository,
    val doseRepository: DoseRepository,
    val settingsRepository: SettingsRepository
) : AndroidViewModel(application) {

    val currentUser: StateFlow<User?> = authRepository.currentUser

    // Active User Settings
    val userSettings: StateFlow<UserSettings> = currentUser.flatMapLatest { user ->
        if (user != null) {
            settingsRepository.getSettingsFlow(user.id).flatMapLatest {
                flowOf(it ?: UserSettings(userId = user.id))
            }
        } else {
            flowOf(UserSettings(userId = ""))
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserSettings(userId = ""))

    // Active Language derived from settings
    val currentLanguage: StateFlow<AppLanguage> = userSettings.flatMapLatest {
        flowOf(AppLanguage.fromCode(it.languageCode))
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppLanguage.ENGLISH)

    // Medications list for current user
    val medications: StateFlow<List<Medication>> = currentUser.flatMapLatest { user ->
        if (user != null) {
            medicationRepository.getAllMedicationsFlow(user.id)
        } else {
            flowOf(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Today's Doses
    val todayDoses: StateFlow<List<DoseEvent>> = currentUser.flatMapLatest { user ->
        if (user != null) {
            doseRepository.getTodayDoseEventsFlow(user.id, DateUtils.getTodayDateString())
        } else {
            flowOf(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered date for History screen
    private val _selectedHistoryDate = MutableStateFlow<String?>(null)
    val selectedHistoryDate: StateFlow<String?> = _selectedHistoryDate.asStateFlow()

    // All Doses / History
    val historyDoses: StateFlow<List<DoseEvent>> = combine(currentUser, _selectedHistoryDate) { user, date ->
        Pair(user, date)
    }.flatMapLatest { (user, date) ->
        if (user != null) {
            if (date != null) {
                doseRepository.getTodayDoseEventsFlow(user.id, date)
            } else {
                doseRepository.getAllDoseEventsFlow(user.id)
            }
        } else {
            flowOf(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Statistics
    private val _stats = MutableStateFlow(
        AdherenceStats(
            overallAdherencePct = 100,
            todayAdherencePct = 100,
            weeklyAdherencePct = 100,
            monthlyAdherencePct = 100,
            totalTaken = 0,
            totalMissed = 0,
            totalSkipped = 0,
            totalScheduledToday = 0,
            takenToday = 0,
            missedToday = 0,
            remainingToday = 0,
            currentStreak = 0,
            bestStreak = 0
        )
    )
    val stats: StateFlow<AdherenceStats> = _stats.asStateFlow()

    // Selected medication for details/editing
    private val _selectedMedication = MutableStateFlow<Medication?>(null)
    val selectedMedication: StateFlow<Medication?> = _selectedMedication.asStateFlow()

    init {
        NotificationHelper.createNotificationChannel(application)
        viewModelScope.launch {
            currentUser.collect { user ->
                if (user != null) {
                    doseRepository.syncDoseEventsForDate(user.id, DateUtils.getTodayDateString())
                    refreshStats()
                }
            }
        }
    }

    fun refreshStats() {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            _stats.value = doseRepository.calculateStats(user.id)
        }
    }

    fun selectMedication(med: Medication?) {
        _selectedMedication.value = med
    }

    fun setHistoryDate(date: String?) {
        _selectedHistoryDate.value = date
    }

    // Dose actions
    fun takeDose(doseId: String) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            doseRepository.markDoseTaken(doseId, user.id)
            refreshStats()
        }
    }

    fun skipDose(doseId: String) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            doseRepository.markDoseSkipped(doseId, user.id)
            refreshStats()
        }
    }

    fun missDose(doseId: String) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            doseRepository.markDoseMissed(doseId, user.id)
            refreshStats()
        }
    }

    // Medication CRUD
    fun saveMedication(
        name: String,
        doseAmount: String,
        doseUnit: String,
        instructions: String,
        frequency: String,
        scheduledTimes: List<String>,
        daysOfWeek: List<Int>,
        startDate: String,
        endDate: String?,
        notes: String?,
        existingMedId: String? = null,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val user = currentUser.value
        if (user == null) {
            onError("You must be logged in to save medications.")
            return
        }
        if (name.isBlank()) {
            onError("Please enter medication name.")
            return
        }
        if (doseAmount.isBlank()) {
            onError("Please enter dose amount.")
            return
        }

        viewModelScope.launch {
            try {
                val timesJson = "[" + scheduledTimes.joinToString(",") { "\"$it\"" } + "]"
                val daysJson = "[" + daysOfWeek.joinToString(",") + "]"
                val med = Medication(
                    id = existingMedId ?: java.util.UUID.randomUUID().toString(),
                    userId = user.id,
                    name = name.trim(),
                    doseAmount = doseAmount.trim(),
                    doseUnit = doseUnit.trim(),
                    instructions = instructions.trim(),
                    frequency = frequency.trim(),
                    scheduledTimesJson = timesJson,
                    daysOfWeekJson = daysJson,
                    startDate = startDate.trim(),
                    endDate = endDate?.takeIf { it.isNotBlank() }?.trim(),
                    notes = notes?.takeIf { it.isNotBlank() }?.trim(),
                    isActive = true
                )
                medicationRepository.saveMedication(med)
                refreshStats()
                onSuccess()
            } catch (e: Exception) {
                onError(e.localizedMessage ?: "Failed to save medication.")
            }
        }
    }

    fun toggleMedicationActive(medId: String, isActive: Boolean) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            medicationRepository.setMedicationActive(medId, user.id, isActive)
            refreshStats()
        }
    }

    fun deleteMedication(medId: String) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            medicationRepository.deleteMedication(medId, user.id)
            if (_selectedMedication.value?.id == medId) {
                _selectedMedication.value = null
            }
            refreshStats()
        }
    }

    // Settings
    fun setLanguage(code: String) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            settingsRepository.updateLanguage(user.id, code)
        }
    }

    fun setTheme(themeMode: String) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            settingsRepository.updateTheme(user.id, themeMode)
        }
    }

    fun updateNotifications(sound: Boolean, vibrate: Boolean, leadMinutes: Int) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            settingsRepository.updateNotificationPreferences(user.id, sound, vibrate, leadMinutes)
        }
    }

    // Auth
    fun login(email: String, password: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val res = authRepository.login(email, password)
            if (res.isSuccess) {
                onResult(true, null)
            } else {
                onResult(false, res.exceptionOrNull()?.message ?: "Login failed.")
            }
        }
    }

    fun signUp(email: String, password: String, fullName: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val res = authRepository.signUp(email, password, fullName)
            if (res.isSuccess) {
                onResult(true, null)
            } else {
                onResult(false, res.exceptionOrNull()?.message ?: "Sign up failed.")
            }
        }
    }

    fun resetPassword(email: String, newPassword: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val res = authRepository.resetPassword(email, newPassword)
            if (res.isSuccess) {
                onResult(true, null)
            } else {
                onResult(false, res.exceptionOrNull()?.message ?: "Reset failed.")
            }
        }
    }

    fun logout() {
        authRepository.logout()
        _selectedMedication.value = null
    }

    fun deleteAccount(onResult: (Boolean, String?) -> Unit) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            val res = authRepository.deleteAccount(user.id)
            if (res.isSuccess) {
                onResult(true, null)
            } else {
                onResult(false, res.exceptionOrNull()?.message ?: "Account deletion failed.")
            }
        }
    }

    companion object {
        fun provideFactory(application: Application): ViewModelProvider.Factory {
            return object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    val db = IsaDoseDatabase.getInstance(application)
                    val doseRepo = DoseRepository(application, db)
                    val medRepo = MedicationRepository(db, doseRepo)
                    val authRepo = AuthRepository(application, db)
                    val settingsRepo = SettingsRepository(db)
                    return IsaDoseViewModel(
                        application = application,
                        authRepository = authRepo,
                        medicationRepository = medRepo,
                        doseRepository = doseRepo,
                        settingsRepository = settingsRepo
                    ) as T
                }
            }
        }
    }
}
