package com.example.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat
import com.example.data.local.IsaDoseDatabase
import com.example.data.model.DoseStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MedicationReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val doseEventId = intent.getStringExtra(NotificationHelper.EXTRA_DOSE_EVENT_ID) ?: return
        val userId = intent.getStringExtra(NotificationHelper.EXTRA_USER_ID) ?: ""

        when (action) {
            NotificationHelper.ACTION_MEDICATION_REMINDER -> {
                val medName = intent.getStringExtra(NotificationHelper.EXTRA_MED_NAME) ?: "Medication"
                val doseInfo = intent.getStringExtra(NotificationHelper.EXTRA_DOSE_INFO) ?: ""
                NotificationHelper.showDoseNotification(context, doseEventId, userId, medName, doseInfo)
            }
            NotificationHelper.ACTION_TAKE_DOSE -> {
                NotificationManagerCompat.from(context).cancel(doseEventId.hashCode())
                if (userId.isNotBlank()) {
                    val pendingResult = goAsync()
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            val db = IsaDoseDatabase.getInstance(context)
                            db.doseEventDao().updateDoseStatus(
                                id = doseEventId,
                                userId = userId,
                                status = DoseStatus.TAKEN.name,
                                actionTimestamp = System.currentTimeMillis()
                            )
                        } finally {
                            pendingResult.finish()
                        }
                    }
                }
            }
            NotificationHelper.ACTION_SKIP_DOSE -> {
                NotificationManagerCompat.from(context).cancel(doseEventId.hashCode())
                if (userId.isNotBlank()) {
                    val pendingResult = goAsync()
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            val db = IsaDoseDatabase.getInstance(context)
                            db.doseEventDao().updateDoseStatus(
                                id = doseEventId,
                                userId = userId,
                                status = DoseStatus.SKIPPED.name,
                                actionTimestamp = System.currentTimeMillis()
                            )
                        } finally {
                            pendingResult.finish()
                        }
                    }
                }
            }
        }
    }
}
