package com.example.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.local.IsaDoseDatabase
import com.example.util.DateUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            action == Intent.ACTION_TIMEZONE_CHANGED ||
            action == Intent.ACTION_TIME_CHANGED
        ) {
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val prefs = context.getSharedPreferences("isadose_auth_prefs", Context.MODE_PRIVATE)
                    val activeUserId = prefs.getString("active_user_id", null) ?: return@launch
                    val db = IsaDoseDatabase.getInstance(context)
                    val settings = db.userSettingsDao().getSettings(activeUserId)
                    if (settings?.soundEnabled == false && settings.vibrationEnabled == false) {
                        return@launch
                    }
                    val today = DateUtils.getTodayDateString()
                    val doses = db.doseEventDao().getDoseEventsForDate(activeUserId, today)
                    val lead = settings?.reminderLeadMinutes ?: 0
                    for (dose in doses) {
                        val timeParts = dose.scheduledTime.split(":")
                        if (timeParts.size == 2) {
                            val hour = timeParts[0].toIntOrNull() ?: continue
                            val min = timeParts[1].toIntOrNull() ?: continue
                            NotificationHelper.scheduleDoseReminder(
                                context = context,
                                doseEventId = dose.id,
                                userId = activeUserId,
                                medicationName = dose.medicationName,
                                doseInfo = "${dose.doseAmount} ${dose.doseUnit}",
                                hour = hour,
                                minute = min,
                                leadMinutes = lead
                            )
                        }
                    }
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
