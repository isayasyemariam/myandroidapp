package com.example.reminder

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.R
import java.util.Calendar

object NotificationHelper {
    const val CHANNEL_ID = "isadose_medication_reminders"
    const val CHANNEL_NAME = "Medication Reminders"
    const val CHANNEL_DESC = "Private alerts for scheduled medication doses"

    const val ACTION_MEDICATION_REMINDER = "com.isadose.app.ACTION_MEDICATION_REMINDER"
    const val ACTION_TAKE_DOSE = "com.isadose.app.ACTION_TAKE_DOSE"
    const val ACTION_SKIP_DOSE = "com.isadose.app.ACTION_SKIP_DOSE"

    const val EXTRA_DOSE_EVENT_ID = "extra_dose_event_id"
    const val EXTRA_USER_ID = "extra_user_id"
    const val EXTRA_MED_NAME = "extra_med_name"
    const val EXTRA_DOSE_INFO = "extra_dose_info"

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, importance).apply {
                description = CHANNEL_DESC
                enableVibration(true)
                enableLights(true)
            }
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun scheduleDoseReminder(
        context: Context,
        doseEventId: String,
        userId: String,
        medicationName: String,
        doseInfo: String,
        hour: Int,
        minute: Int,
        leadMinutes: Int = 0
    ) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (leadMinutes > 0) {
                add(Calendar.MINUTE, -leadMinutes)
            }
            if (before(Calendar.getInstance())) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        val intent = Intent(context, MedicationReminderReceiver::class.java).apply {
            action = ACTION_MEDICATION_REMINDER
            putExtra(EXTRA_DOSE_EVENT_ID, doseEventId)
            putExtra(EXTRA_USER_ID, userId)
            putExtra(EXTRA_MED_NAME, medicationName)
            putExtra(EXTRA_DOSE_INFO, doseInfo)
        }

        val requestCode = doseEventId.hashCode()
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        calendar.timeInMillis,
                        pendingIntent
                    )
                } else {
                    alarmManager.setAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        calendar.timeInMillis,
                        pendingIntent
                    )
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            }
        } catch (e: SecurityException) {
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                calendar.timeInMillis,
                pendingIntent
            )
        }
    }

    fun cancelDoseReminder(context: Context, doseEventId: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, MedicationReminderReceiver::class.java).apply {
            action = ACTION_MEDICATION_REMINDER
        }
        val requestCode = doseEventId.hashCode()
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }

    fun showDoseNotification(
        context: Context,
        doseEventId: String,
        userId: String,
        medicationName: String,
        doseInfo: String
    ) {
        createNotificationChannel(context)

        // Tap opens app
        val contentIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            context,
            doseEventId.hashCode(),
            contentIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Action: Take Dose
        val takeIntent = Intent(context, MedicationReminderReceiver::class.java).apply {
            action = ACTION_TAKE_DOSE
            putExtra(EXTRA_DOSE_EVENT_ID, doseEventId)
            putExtra(EXTRA_USER_ID, userId)
        }
        val takePendingIntent = PendingIntent.getBroadcast(
            context,
            (doseEventId + "_take").hashCode(),
            takeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Action: Skip Dose
        val skipIntent = Intent(context, MedicationReminderReceiver::class.java).apply {
            action = ACTION_SKIP_DOSE
            putExtra(EXTRA_DOSE_EVENT_ID, doseEventId)
            putExtra(EXTRA_USER_ID, userId)
        }
        val skipPendingIntent = PendingIntent.getBroadcast(
            context,
            (doseEventId + "_skip").hashCode(),
            skipIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Time for your medication: $medicationName")
            .setContentText("Dose: $doseInfo")
            .setStyle(NotificationCompat.BigTextStyle().bigText("Time to take your scheduled dose of $medicationName ($doseInfo). Tap to open IsaDose or record below."))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setContentIntent(contentPendingIntent)
            .setAutoCancel(true)
            .addAction(android.R.drawable.checkbox_on_background, "Take Dose", takePendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Skip", skipPendingIntent)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(doseEventId.hashCode(), notification)
        } catch (e: SecurityException) {
            // Notifications permission not granted
        }
    }
}
