package com.example.i18n

enum class AppLanguage(
    val code: String,
    val nativeName: String,
    val englishName: String,
    val isRtl: Boolean = false
) {
    ENGLISH("en", "English", "English"),
    SPANISH("es", "Español", "Spanish"),
    FRENCH("fr", "Français", "French"),
    GERMAN("de", "Deutsch", "German"),
    PORTUGUESE("pt", "Português", "Portuguese"),
    ITALIAN("it", "Italiano", "Italian"),
    DUTCH("nl", "Nederlands", "Dutch"),
    POLISH("pl", "Polski", "Polish"),
    TURKISH("tr", "Türkçe", "Turkish"),
    ARABIC("ar", "العربية", "Arabic", isRtl = true),
    RUSSIAN("ru", "Русский", "Russian"),
    UKRAINIAN("uk", "Українська", "Ukrainian"),
    HINDI("hi", "हिन्दी", "Hindi"),
    BENGALI("bn", "বাংলা", "Bengali"),
    INDONESIAN("id", "Bahasa Indonesia", "Indonesian"),
    MALAY("ms", "Bahasa Melayu", "Malay"),
    VIETNAMESE("vi", "Tiếng Việt", "Vietnamese"),
    THAI("th", "ไทย", "Thai"),
    JAPANESE("ja", "日本語", "Japanese"),
    KOREAN("ko", "한국어", "Korean");

    companion object {
        fun fromCode(code: String): AppLanguage {
            return entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: ENGLISH
        }
    }
}
