package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "medications")
data class Medication(
    @PrimaryKey
    val id: String,
    val userId: String,
    val name: String,
    val doseAmount: String,
    val doseUnit: String, // pills, capsules, tablets, mg, ml, drops, puffs, units
    val instructions: String, // With food, Before meal, After meal, Empty stomach, Bedtime, As needed
    val frequency: String, // Once daily, Twice daily, 3 times daily, 4 times daily, Every 8 hours, etc.
    val scheduledTimesJson: String, // e.g. ["08:00","20:00"]
    val daysOfWeekJson: String = "[]", // [] = every day, or [1,2,3,4,5,6,7] (1=Monday, 7=Sunday)
    val startDate: String, // YYYY-MM-DD
    val endDate: String? = null, // YYYY-MM-DD or null for ongoing
    val notes: String? = null,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
