package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.DoseEvent
import kotlinx.coroutines.flow.Flow

@Dao
interface DoseEventDao {
    @Query("SELECT * FROM dose_events WHERE userId = :userId AND scheduledDate = :date ORDER BY scheduledTime ASC")
    fun getDoseEventsForDateFlow(userId: String, date: String): Flow<List<DoseEvent>>

    @Query("SELECT * FROM dose_events WHERE userId = :userId AND scheduledDate = :date ORDER BY scheduledTime ASC")
    suspend fun getDoseEventsForDate(userId: String, date: String): List<DoseEvent>

    @Query("SELECT * FROM dose_events WHERE userId = :userId ORDER BY scheduledDate DESC, scheduledTime DESC")
    fun getAllDoseEventsFlow(userId: String): Flow<List<DoseEvent>>

    @Query("SELECT * FROM dose_events WHERE userId = :userId AND medicationId = :medicationId ORDER BY scheduledDate DESC, scheduledTime DESC")
    fun getDoseEventsForMedicationFlow(userId: String, medicationId: String): Flow<List<DoseEvent>>

    @Query("SELECT * FROM dose_events WHERE id = :id AND userId = :userId LIMIT 1")
    suspend fun getDoseEventById(id: String, userId: String): DoseEvent?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertDoseEvents(events: List<DoseEvent>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateDoseEvent(event: DoseEvent)

    @Query("UPDATE dose_events SET status = :status, actionTimestamp = :actionTimestamp WHERE id = :id AND userId = :userId")
    suspend fun updateDoseStatus(id: String, userId: String, status: String, actionTimestamp: Long?)

    @Query("SELECT COUNT(*) FROM dose_events WHERE userId = :userId")
    suspend fun getTotalDoseCount(userId: String): Int

    @Query("SELECT COUNT(*) FROM dose_events WHERE userId = :userId AND status = :status")
    suspend fun getDoseCountByStatus(userId: String, status: String): Int

    @Query("SELECT COUNT(*) FROM dose_events WHERE userId = :userId AND scheduledDate = :date AND status = :status")
    suspend fun getDoseCountByDateAndStatus(userId: String, date: String, status: String): Int

    @Query("SELECT COUNT(*) FROM dose_events WHERE userId = :userId AND scheduledDate = :date")
    suspend fun getDoseCountByDate(userId: String, date: String): Int

    @Query("SELECT * FROM dose_events WHERE userId = :userId AND scheduledDate >= :sinceDate ORDER BY scheduledDate ASC")
    suspend fun getDoseEventsSince(userId: String, sinceDate: String): List<DoseEvent>

    @Query("DELETE FROM dose_events WHERE medicationId = :medicationId AND userId = :userId")
    suspend fun deleteEventsForMedication(medicationId: String, userId: String)

    @Query("DELETE FROM dose_events WHERE userId = :userId")
    suspend fun deleteAllEventsForUser(userId: String)
}
