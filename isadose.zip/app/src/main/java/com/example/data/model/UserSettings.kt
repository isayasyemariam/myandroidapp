package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_settings")
data class UserSettings(
    @PrimaryKey
    val userId: String,
    val languageCode: String = "en",
    val themeMode: String = "SYSTEM", // "SYSTEM", "LIGHT", "DARK"
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val reminderLeadMinutes: Int = 0 // 0 = at time, 5, 10, 15
)
