package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Medication
import kotlinx.coroutines.flow.Flow

@Dao
interface MedicationDao {
    @Query("SELECT * FROM medications WHERE userId = :userId ORDER BY createdAt DESC")
    fun getAllMedicationsFlow(userId: String): Flow<List<Medication>>

    @Query("SELECT * FROM medications WHERE userId = :userId AND isActive = 1 ORDER BY name ASC")
    fun getActiveMedicationsFlow(userId: String): Flow<List<Medication>>

    @Query("SELECT * FROM medications WHERE userId = :userId AND isActive = 1")
    suspend fun getActiveMedications(userId: String): List<Medication>

    @Query("SELECT * FROM medications WHERE id = :id AND userId = :userId LIMIT 1")
    suspend fun getMedicationById(id: String, userId: String): Medication?

    @Query("SELECT * FROM medications WHERE id = :id AND userId = :userId LIMIT 1")
    fun getMedicationByIdFlow(id: String, userId: String): Flow<Medication?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMedication(medication: Medication)

    @Update
    suspend fun updateMedication(medication: Medication)

    @Query("UPDATE medications SET isActive = :isActive WHERE id = :id AND userId = :userId")
    suspend fun setMedicationActive(id: String, userId: String, isActive: Boolean)

    @Query("DELETE FROM medications WHERE id = :id AND userId = :userId")
    suspend fun deleteMedication(id: String, userId: String)

    @Query("DELETE FROM medications WHERE userId = :userId")
    suspend fun deleteAllMedicationsForUser(userId: String)
}
