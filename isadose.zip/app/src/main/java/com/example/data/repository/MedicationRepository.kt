package com.example.data.repository

import com.example.data.local.IsaDoseDatabase
import com.example.data.model.Medication
import com.example.util.DateUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class MedicationRepository(
    private val database: IsaDoseDatabase,
    private val doseRepository: DoseRepository
) {
    fun getAllMedicationsFlow(userId: String): Flow<List<Medication>> {
        return database.medicationDao().getAllMedicationsFlow(userId)
    }

    fun getActiveMedicationsFlow(userId: String): Flow<List<Medication>> {
        return database.medicationDao().getActiveMedicationsFlow(userId)
    }

    suspend fun getMedicationById(id: String, userId: String): Medication? = withContext(Dispatchers.IO) {
        database.medicationDao().getMedicationById(id, userId)
    }

    fun getMedicationByIdFlow(id: String, userId: String): Flow<Medication?> {
        return database.medicationDao().getMedicationByIdFlow(id, userId)
    }

    suspend fun saveMedication(medication: Medication) = withContext(Dispatchers.IO) {
        database.medicationDao().insertMedication(medication)
        // Immediately sync dose events for today so newly added medication appears on schedule
        doseRepository.syncDoseEventsForDate(medication.userId, DateUtils.getTodayDateString())
    }

    suspend fun setMedicationActive(id: String, userId: String, isActive: Boolean) = withContext(Dispatchers.IO) {
        database.medicationDao().setMedicationActive(id, userId, isActive)
        doseRepository.syncDoseEventsForDate(userId, DateUtils.getTodayDateString())
    }

    suspend fun deleteMedication(id: String, userId: String) = withContext(Dispatchers.IO) {
        database.medicationDao().deleteMedication(id, userId)
        database.doseEventDao().deleteEventsForMedication(id, userId)
    }
}
