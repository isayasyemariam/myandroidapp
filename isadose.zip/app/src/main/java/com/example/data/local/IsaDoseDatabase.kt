package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.DoseEvent
import com.example.data.model.Medication
import com.example.data.model.User
import com.example.data.model.UserSettings

@Database(
    entities = [
        User::class,
        UserSettings::class,
        Medication::class,
        DoseEvent::class
    ],
    version = 1,
    exportSchema = false
)
abstract class IsaDoseDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun userSettingsDao(): UserSettingsDao
    abstract fun medicationDao(): MedicationDao
    abstract fun doseEventDao(): DoseEventDao

    companion object {
        @Volatile
        private var INSTANCE: IsaDoseDatabase? = null

        fun getInstance(context: Context): IsaDoseDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    IsaDoseDatabase::class.java,
                    "isadose_master.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
