package com.example.data.repository

import com.example.data.local.IsaDoseDatabase
import com.example.data.model.UserSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class SettingsRepository(
    private val database: IsaDoseDatabase
) {
    fun getSettingsFlow(userId: String): Flow<UserSettings?> {
        return database.userSettingsDao().getSettingsFlow(userId)
    }

    suspend fun getSettings(userId: String): UserSettings = withContext(Dispatchers.IO) {
        database.userSettingsDao().getSettings(userId) ?: UserSettings(userId = userId)
    }

    suspend fun updateLanguage(userId: String, languageCode: String) = withContext(Dispatchers.IO) {
        val current = getSettings(userId)
        database.userSettingsDao().insertOrUpdate(current.copy(languageCode = languageCode))
    }

    suspend fun updateTheme(userId: String, themeMode: String) = withContext(Dispatchers.IO) {
        val current = getSettings(userId)
        database.userSettingsDao().insertOrUpdate(current.copy(themeMode = themeMode))
    }

    suspend fun updateNotificationPreferences(
        userId: String,
        soundEnabled: Boolean,
        vibrationEnabled: Boolean,
        leadMinutes: Int
    ) = withContext(Dispatchers.IO) {
        val current = getSettings(userId)
        database.userSettingsDao().insertOrUpdate(
            current.copy(
                soundEnabled = soundEnabled,
                vibrationEnabled = vibrationEnabled,
                reminderLeadMinutes = leadMinutes
            )
        )
    }
}
