package com.example.data.repository

import android.content.Context
import com.example.data.local.IsaDoseDatabase
import com.example.data.model.DoseEvent
import com.example.data.model.DoseStatus
import com.example.reminder.NotificationHelper
import com.example.util.DateUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

data class AdherenceStats(
    val overallAdherencePct: Int,
    val todayAdherencePct: Int,
    val weeklyAdherencePct: Int,
    val monthlyAdherencePct: Int,
    val totalTaken: Int,
    val totalMissed: Int,
    val totalSkipped: Int,
    val totalScheduledToday: Int,
    val takenToday: Int,
    val missedToday: Int,
    val remainingToday: Int,
    val currentStreak: Int,
    val bestStreak: Int
)

class DoseRepository(
    private val context: Context,
    private val database: IsaDoseDatabase
) {
    fun getTodayDoseEventsFlow(userId: String, date: String = DateUtils.getTodayDateString()): Flow<List<DoseEvent>> {
        return database.doseEventDao().getDoseEventsForDateFlow(userId, date)
    }

    fun getAllDoseEventsFlow(userId: String): Flow<List<DoseEvent>> {
        return database.doseEventDao().getAllDoseEventsFlow(userId)
    }

    fun getDoseEventsForMedicationFlow(userId: String, medicationId: String): Flow<List<DoseEvent>> {
        return database.doseEventDao().getDoseEventsForMedicationFlow(userId, medicationId)
    }

    suspend fun syncDoseEventsForDate(userId: String, date: String = DateUtils.getTodayDateString()) = withContext(Dispatchers.IO) {
        val activeMeds = database.medicationDao().getActiveMedications(userId)
        val dayOfWeek = DateUtils.getDayOfWeek(date)
        val newEvents = mutableListOf<DoseEvent>()

        for (med in activeMeds) {
            if (!DateUtils.isDateInRange(date, med.startDate, med.endDate)) {
                continue
            }
            val allowedDays = DateUtils.parseDaysOfWeekJson(med.daysOfWeekJson)
            if (allowedDays.isNotEmpty() && !allowedDays.contains(dayOfWeek)) {
                continue
            }

            val times = DateUtils.parseScheduledTimesJson(med.scheduledTimesJson)
            for (time in times) {
                val eventId = "${userId}_${med.id}_${date}_${time.replace(":", "")}"
                val existing = database.doseEventDao().getDoseEventById(eventId, userId)
                if (existing == null) {
                    val event = DoseEvent(
                        id = eventId,
                        userId = userId,
                        medicationId = med.id,
                        medicationName = med.name,
                        doseAmount = med.doseAmount,
                        doseUnit = med.doseUnit,
                        scheduledDate = date,
                        scheduledTime = time,
                        status = DoseStatus.UPCOMING.name
                    )
                    newEvents.add(event)
                }
            }
        }

        if (newEvents.isNotEmpty()) {
            database.doseEventDao().insertDoseEvents(newEvents)

            // Schedule notification alerts for today's upcoming events
            if (date == DateUtils.getTodayDateString()) {
                val settings = database.userSettingsDao().getSettings(userId)
                val lead = settings?.reminderLeadMinutes ?: 0
                for (event in newEvents) {
                    val timeParts = event.scheduledTime.split(":")
                    if (timeParts.size == 2) {
                        val hour = timeParts[0].toIntOrNull() ?: continue
                        val min = timeParts[1].toIntOrNull() ?: continue
                        NotificationHelper.scheduleDoseReminder(
                            context = context,
                            doseEventId = event.id,
                            userId = userId,
                            medicationName = event.medicationName,
                            doseInfo = "${event.doseAmount} ${event.doseUnit}",
                            hour = hour,
                            minute = min,
                            leadMinutes = lead
                        )
                    }
                }
            }
        }
    }

    suspend fun markDoseTaken(doseId: String, userId: String) = withContext(Dispatchers.IO) {
        database.doseEventDao().updateDoseStatus(
            id = doseId,
            userId = userId,
            status = DoseStatus.TAKEN.name,
            actionTimestamp = System.currentTimeMillis()
        )
        NotificationHelper.cancelDoseReminder(context, doseId)
    }

    suspend fun markDoseSkipped(doseId: String, userId: String) = withContext(Dispatchers.IO) {
        database.doseEventDao().updateDoseStatus(
            id = doseId,
            userId = userId,
            status = DoseStatus.SKIPPED.name,
            actionTimestamp = System.currentTimeMillis()
        )
        NotificationHelper.cancelDoseReminder(context, doseId)
    }

    suspend fun markDoseMissed(doseId: String, userId: String) = withContext(Dispatchers.IO) {
        database.doseEventDao().updateDoseStatus(
            id = doseId,
            userId = userId,
            status = DoseStatus.MISSED.name,
            actionTimestamp = System.currentTimeMillis()
        )
        NotificationHelper.cancelDoseReminder(context, doseId)
    }

    suspend fun calculateStats(userId: String): AdherenceStats = withContext(Dispatchers.IO) {
        val today = DateUtils.getTodayDateString()
        syncDoseEventsForDate(userId, today)

        val totalTaken = database.doseEventDao().getDoseCountByStatus(userId, DoseStatus.TAKEN.name)
        val totalMissed = database.doseEventDao().getDoseCountByStatus(userId, DoseStatus.MISSED.name)
        val totalSkipped = database.doseEventDao().getDoseCountByStatus(userId, DoseStatus.SKIPPED.name)

        val totalRecorded = totalTaken + totalMissed + totalSkipped
        val overallAdherence = if (totalRecorded > 0) ((totalTaken.toDouble() / totalRecorded) * 100).toInt() else 100

        // Today's numbers
        val todayDoses = database.doseEventDao().getDoseEventsForDate(userId, today)
        val totalToday = todayDoses.size
        val takenToday = todayDoses.count { it.status == DoseStatus.TAKEN.name }
        val missedToday = todayDoses.count { it.status == DoseStatus.MISSED.name }
        val remainingToday = todayDoses.count { it.status == DoseStatus.UPCOMING.name }
        val resolvedToday = takenToday + missedToday + todayDoses.count { it.status == DoseStatus.SKIPPED.name }
        val todayAdherence = if (resolvedToday > 0) ((takenToday.toDouble() / resolvedToday) * 100).toInt() else if (totalToday > 0) 0 else 100

        // Past 7 days
        val past7Days = DateUtils.getDatesForPastDays(7)
        var weeklyTaken = 0
        var weeklyTotal = 0
        for (d in past7Days) {
            val dayEvents = database.doseEventDao().getDoseEventsForDate(userId, d)
            weeklyTaken += dayEvents.count { it.status == DoseStatus.TAKEN.name }
            weeklyTotal += dayEvents.count { it.status == DoseStatus.TAKEN.name || it.status == DoseStatus.MISSED.name || it.status == DoseStatus.SKIPPED.name }
        }
        val weeklyAdherence = if (weeklyTotal > 0) ((weeklyTaken.toDouble() / weeklyTotal) * 100).toInt() else 100

        // Past 30 days
        val past30Days = DateUtils.getDatesForPastDays(30)
        var monthlyTaken = 0
        var monthlyTotal = 0
        for (d in past30Days) {
            val dayEvents = database.doseEventDao().getDoseEventsForDate(userId, d)
            monthlyTaken += dayEvents.count { it.status == DoseStatus.TAKEN.name }
            monthlyTotal += dayEvents.count { it.status == DoseStatus.TAKEN.name || it.status == DoseStatus.MISSED.name || it.status == DoseStatus.SKIPPED.name }
        }
        val monthlyAdherence = if (monthlyTotal > 0) ((monthlyTaken.toDouble() / monthlyTotal) * 100).toInt() else 100

        // Streak Calculation
        var currentStreak = 0
        var bestStreak = 0
        var tempStreak = 0

        // Check consecutive past days
        for (d in past30Days.reversed()) {
            val dayEvents = database.doseEventDao().getDoseEventsForDate(userId, d)
            if (dayEvents.isNotEmpty()) {
                val allTaken = dayEvents.all { it.status == DoseStatus.TAKEN.name }
                if (allTaken) {
                    tempStreak++
                    if (tempStreak > bestStreak) bestStreak = tempStreak
                } else {
                    if (currentStreak == 0 && d != today) {
                        currentStreak = tempStreak
                    }
                    tempStreak = 0
                }
            }
        }
        if (currentStreak == 0) currentStreak = tempStreak
        if (tempStreak > bestStreak) bestStreak = tempStreak

        AdherenceStats(
            overallAdherencePct = overallAdherence,
            todayAdherencePct = todayAdherence,
            weeklyAdherencePct = weeklyAdherence,
            monthlyAdherencePct = monthlyAdherence,
            totalTaken = totalTaken,
            totalMissed = totalMissed,
            totalSkipped = totalSkipped,
            totalScheduledToday = totalToday,
            takenToday = takenToday,
            missedToday = missedToday,
            remainingToday = remainingToday,
            currentStreak = currentStreak,
            bestStreak = bestStreak
        )
    }
}
