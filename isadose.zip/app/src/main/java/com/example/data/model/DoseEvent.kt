package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

enum class DoseStatus {
    UPCOMING,
    TAKEN,
    MISSED,
    SKIPPED
}

@Entity(
    tableName = "dose_events",
    indices = [
        Index(
            value = ["userId", "medicationId", "scheduledDate", "scheduledTime"],
            unique = true
        ),
        Index(value = ["userId", "scheduledDate"])
    ]
)
data class DoseEvent(
    @PrimaryKey
    val id: String,
    val userId: String,
    val medicationId: String,
    val medicationName: String,
    val doseAmount: String,
    val doseUnit: String,
    val scheduledDate: String, // YYYY-MM-DD
    val scheduledTime: String, // HH:mm
    val status: String = DoseStatus.UPCOMING.name, // UPCOMING, TAKEN, MISSED, SKIPPED
    val actionTimestamp: Long? = null,
    val notes: String? = null
)
