package com.example.data.repository

import android.content.Context
import com.example.data.local.IsaDoseDatabase
import com.example.data.model.User
import com.example.data.model.UserSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.util.UUID

class AuthRepository(
    private val context: Context,
    private val database: IsaDoseDatabase
) {
    private val prefs = context.getSharedPreferences("isadose_auth_prefs", Context.MODE_PRIVATE)
    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    init {
        val savedUserId = prefs.getString("active_user_id", null)
        if (savedUserId != null) {
            CoroutineScope(Dispatchers.IO).launch {
                val user = database.userDao().getUserById(savedUserId)
                _currentUser.value = user
            }
        }
    }

    private fun hashPassword(password: String): String {
        val salt = "isa_dose_secure_salt_2026"
        val bytes = MessageDigest.getInstance("SHA-256").digest((password + salt).toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    suspend fun signUp(email: String, password: String, fullName: String): Result<User> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()
        if (cleanEmail.isBlank() || !cleanEmail.contains("@")) {
            return@withContext Result.failure(IllegalArgumentException("Please enter a valid email address."))
        }
        if (password.length < 6) {
            return@withContext Result.failure(IllegalArgumentException("Password must be at least 6 characters."))
        }
        val existing = database.userDao().getUserByEmail(cleanEmail)
        if (existing != null) {
            return@withContext Result.failure(IllegalArgumentException("An account with this email already exists."))
        }

        val userId = UUID.randomUUID().toString()
        val user = User(
            id = userId,
            email = cleanEmail,
            passwordHash = hashPassword(password),
            fullName = fullName.trim().ifBlank { "IsaDose User" }
        )
        database.userDao().insertUser(user)

        // Initialize user settings
        database.userSettingsDao().insertOrUpdate(
            UserSettings(userId = userId)
        )

        prefs.edit().putString("active_user_id", userId).apply()
        _currentUser.value = user
        Result.success(user)
    }

    suspend fun login(email: String, password: String): Result<User> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()
        val user = database.userDao().getUserByEmail(cleanEmail)
            ?: return@withContext Result.failure(IllegalArgumentException("No account found with this email."))

        if (user.passwordHash != hashPassword(password)) {
            return@withContext Result.failure(IllegalArgumentException("Incorrect password."))
        }

        prefs.edit().putString("active_user_id", user.id).apply()
        _currentUser.value = user
        Result.success(user)
    }

    suspend fun resetPassword(email: String, newPassword: String): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()
        if (newPassword.length < 6) {
            return@withContext Result.failure(IllegalArgumentException("Password must be at least 6 characters."))
        }
        val user = database.userDao().getUserByEmail(cleanEmail)
            ?: return@withContext Result.failure(IllegalArgumentException("No account registered with this email."))

        val newHash = hashPassword(newPassword)
        database.userDao().updatePasswordByEmail(cleanEmail, newHash)
        Result.success(Unit)
    }

    fun logout() {
        prefs.edit().remove("active_user_id").apply()
        _currentUser.value = null
    }

    suspend fun deleteAccount(userId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            // Delete all user medication records
            database.medicationDao().deleteAllMedicationsForUser(userId)
            // Delete all user dose history
            database.doseEventDao().deleteAllEventsForUser(userId)
            // Delete user settings
            database.userSettingsDao().deleteSettingsForUser(userId)
            // Delete user credentials
            database.userDao().deleteUser(userId)

            logout()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
