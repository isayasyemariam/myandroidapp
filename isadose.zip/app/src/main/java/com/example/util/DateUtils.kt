package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DateUtils {
    private val isoDateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.US)

    fun getTodayDateString(): String {
        return isoDateFormat.format(Date())
    }

    fun getCurrentTimeString(): String {
        return timeFormat.format(Date())
    }

    fun getDayOfWeek(dateStr: String): Int {
        return try {
            val date = isoDateFormat.parse(dateStr) ?: return 1
            val cal = Calendar.getInstance()
            cal.time = date
            val dow = cal.get(Calendar.DAY_OF_WEEK)
            // Convert Java Calendar (1=Sunday, 2=Monday, ..., 7=Saturday) to ISO (1=Monday, 7=Sunday)
            if (dow == Calendar.SUNDAY) 7 else dow - 1
        } catch (e: Exception) {
            1
        }
    }

    fun isDateInRange(dateStr: String, startDate: String, endDate: String?): Boolean {
        if (dateStr < startDate) return false
        if (endDate != null && endDate.isNotBlank() && dateStr > endDate) return false
        return true
    }

    fun parseScheduledTimesJson(json: String): List<String> {
        if (json.isBlank() || json == "[]") return listOf("08:00")
        return json.removePrefix("[").removeSuffix("]")
            .split(",")
            .map { it.replace("\"", "").trim() }
            .filter { it.isNotBlank() }
    }

    fun parseDaysOfWeekJson(json: String): List<Int> {
        if (json.isBlank() || json == "[]") return emptyList()
        return json.removePrefix("[").removeSuffix("]")
            .split(",")
            .mapNotNull { it.replace("\"", "").trim().toIntOrNull() }
    }

    fun formatDisplayDate(dateStr: String): String {
        return try {
            val date = isoDateFormat.parse(dateStr) ?: return dateStr
            val displayFormat = SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault())
            displayFormat.format(date)
        } catch (e: Exception) {
            dateStr
        }
    }

    fun formatActionTime(timestamp: Long?): String {
        if (timestamp == null) return ""
        val sdf = SimpleDateFormat("HH:mm, MMM d", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    fun getGreeting(): String {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when {
            hour in 5..11 -> "greeting_morning"
            hour in 12..17 -> "greeting_afternoon"
            else -> "greeting_evening"
        }
    }

    fun getDatesForPastDays(days: Int): List<String> {
        val list = mutableListOf<String>()
        val cal = Calendar.getInstance()
        for (i in 0 until days) {
            list.add(isoDateFormat.format(cal.time))
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }
        return list.reversed()
    }
}
