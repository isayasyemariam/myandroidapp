package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.i18n.AppLanguage
import com.example.util.DateUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("IsaDose", appName)
    }

    @Test
    fun `verify 20 languages supported and amharic excluded`() {
        assertEquals(20, AppLanguage.entries.size)
        val codes = AppLanguage.entries.map { it.code }
        assertTrue("Amharic must be excluded", !codes.contains("am"))
        assertTrue("English must be present", codes.contains("en"))
        assertTrue("Arabic must be present", codes.contains("ar"))
        assertTrue("Arabic must be RTL", AppLanguage.ARABIC.isRtl)
    }

    @Test
    fun `verify date parsing and formatting`() {
        val today = DateUtils.getTodayDateString()
        assertNotNull(today)
        assertTrue(today.matches(Regex("\\d{4}-\\d{2}-\\d{2}")))

        val times = DateUtils.parseScheduledTimesJson("[\"08:00\",\"20:00\"]")
        assertEquals(2, times.size)
        assertEquals("08:00", times[0])
        assertEquals("20:00", times[1])
    }
}
